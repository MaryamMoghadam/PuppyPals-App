const aws = {
	secretKey: 'YourOwnAWS3SecretKey',
	accessKey: 'YourOwnAWS3AccessKey'
}

module.exports = aws