const firebaseConfig = {
  apiKey: "YourOwnFirebaseAPIKey",
  authDomain: "YourOwnFirebaseauthDomain",
  databaseURL: "YourOwnFirebasedatabaseURL",
  projectId: "YourOwnFirebaseprojectId",
  storageBucket: "OPTIONAL",
  messagingSenderId: "YourOwnFirebasemessagingSenderId"
};

module.exports = firebaseConfig