var firebaseConfig = {
  apiKey: null,
  authDomain: null,
  databaseURL: null,
  projectId: null,
  storageBucket: null,
  messagingSenderId: null
};

module.exports = firebaseConfig;