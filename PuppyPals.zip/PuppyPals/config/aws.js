const aws = {
	secretKey: null,
	accessKey: null
}

module.exports = aws